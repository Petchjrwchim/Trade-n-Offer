# Firebase configuration for frontend
FIREBASE_CONFIG = {
    "apiKey": "AIzaSyDx43F34QRLQss07udVOf7wfURDaVIZ9EY",
    "authDomain": "tnof-98bb3.firebaseapp.com",
    "databaseURL": "https://tnof-98bb3-default-rtdb.asia-southeast1.firebasedatabase.app",
    "projectId": "tnof-98bb3",
    "storageBucket": "tnof-98bb3.firebasestorage.app",
    "messagingSenderId": "770087345899",
    "appId": "1:770087345899:web:3c7759b395c57ea8a4a8ae"
}